﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class QF : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Delcarar objeto instanciando clase
        private static Capa_Negocio.QF QF1 = new Capa_Negocio.QF();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            string dni = txtDni.Text;
            string domicilio = txtDomicilio.Text;
            string experienciaLaboral = txtExperienciaLaboral.Text;
            if (apellidos == "")
                Response.Write("Ingrese apellidos");
            else if (nombres == "")
                Response.Write("Ingrese nombres");
            else if (dni == "")
                Response.Write("Ingrese dni");
            else if (domicilio == "")
                Response.Write("Ingrese la domicilio");
            else if (experienciaLaboral == "")
                Response.Write("Ingrese Experiencia Laboral");
            else
            {
                QF1.Apellidos = apellidos;
                QF1.Nombres = nombres;
                QF1.Dni = dni;
                QF1.Domicilio = domicilio;
                QF1.ExperienciaLaboral = experienciaLaboral;
                // enviar un mensaje de conformidad
                Response.Write("Se ha agregado los atributos al objeto");
            }
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  "Apellidos: " + QF1.Apellidos + " Nombres:" + QF1.Nombres + " Dni:" + QF1.Dni + " Domicilio:" + QF1.Domicilio + " Experiencia Laboral:" + QF1.ExperienciaLaboral
                );
        }

        protected void btnSupervisar_Click(object sender, EventArgs e)
        {
            Response.Write(QF1.Supervisar());
        }

        protected void btnAtender_Click(object sender, EventArgs e)
        {
            Response.Write(QF1.Atender());
        }
    }
}