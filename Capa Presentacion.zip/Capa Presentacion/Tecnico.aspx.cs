﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        //Delcarar objeto instanciando clase
        private static Capa_Negocio.Tecnico tecnico1 = new Capa_Negocio.Tecnico();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            string experienciaLaboral = txtExperienciaLaboral.Text;
            string estudios = txtEstudios.Text;
            string domicilio = txtDomicilio.Text;
            if (apellidos == "")
                Response.Write("Ingrese apellidos");
            else if (nombres == "")
                Response.Write("Ingrese nombres");
            else if (experienciaLaboral == "")
                Response.Write("Ingrese la experiencia laboral");
            else if (estudios == "")
                Response.Write("Ingrese estudios");
            else if (domicilio == "")
                Response.Write("Ingrese el domicilio");
            tecnico1.Apellidos = apellidos;
            tecnico1.Nombre = nombres;
            tecnico1.ExperienciaLaboral = experienciaLaboral;
            tecnico1.Estudios = estudios;
            tecnico1.Domicilio = domicilio;
            // enviar un mensaje de conformidad
            Response.Write("Se ha agregado los atributos al objeto");
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  " Apellidos:" + tecnico1.Apellidos + " Nombres:" + tecnico1.Nombre + " Experiencia Laboral:" + tecnico1.ExperienciaLaboral + " Estudios:" + tecnico1.Estudios + " Domicilio:" + tecnico1.Domicilio
                );
        }

        protected void btnControlarVentas_Click(object sender, EventArgs e)
        {
            Response.Write(tecnico1.ControlarVentas());
        }

        protected void btnAtenderVentas_Click(object sender, EventArgs e)
        {
            Response.Write(tecnico1.AtenderVentas());
        }

        protected void btnBalanceDiario_Click(object sender, EventArgs e)
        {
            // Escribir el metodo balance diario
            lblRespuesta.Text = "El balance diario es: " + tecnico1.BalanceDiario();
        }
    }
}