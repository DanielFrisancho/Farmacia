﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class Caja : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Delcarar objeto instanciando clase
        private static Capa_Negocio.Caja caja1 = new Capa_Negocio.Caja();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string ubicacion = txtUbicacion.Text;
            string capacidad = txtCapacidad.Text;
            if (ubicacion == "")
                Response.Write("Ingrese ubicacion");
            else if (capacidad == "")
                Response.Write("Ingrese capacidad");
            else
            {
                caja1.Ubicacion = ubicacion;
                caja1.Capacidad = capacidad;
                // enviar un mensaje de conformidad
                Response.Write("Se ha agregado los atributos al objeto");
            }
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  " Ubicacion:" + caja1.Ubicacion + " Nombres:" + caja1.Capacidad
                );
        }

        protected void btnAdministrar_Click(object sender, EventArgs e)
        {
            Response.Write(caja1.Administrar());
        }

        protected void btnRecepcionarDinero_Click(object sender, EventArgs e)
        {
            Response.Write(caja1.RecepcionarDinero());
        }
    }
}