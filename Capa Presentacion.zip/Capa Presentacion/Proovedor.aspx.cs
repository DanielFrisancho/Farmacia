﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class Proovedor : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Delcarar objeto instanciando clase
        private static Capa_Negocio.Proovedor proovedor1 = new Capa_Negocio.Proovedor();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string apellidos = txtApellidos.Text;
            string nombres = txtNombres.Text;
            string dni = txtDni.Text;
            string localTrabajo = txtLocalTrabajo.Text;
            if (apellidos == "")
                Response.Write("Ingrese apellidos");
            else if (nombres == "")
                Response.Write("Ingrese nombres");
            else if (dni == "")
                Response.Write("Ingrese dni");
            else if (localTrabajo == "")
                Response.Write("Ingrese local de trabajo");
            else
            {
                proovedor1.Apellidos = apellidos;
                proovedor1.Nombres = nombres;
                proovedor1.Dni = dni;
                proovedor1.LocalTrabajo = localTrabajo;
                // enviar un mensaje de conformidad
                Response.Write("Se ha agregado los atributos al objeto");
            }
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  "Apellidos: " + proovedor1.Apellidos + " Nombres:" + proovedor1.Nombres + " Dni:" + proovedor1.Dni + " Local de trabajo:" + proovedor1.LocalTrabajo
                );
        }

        protected void btnEntregarProductos_Click(object sender, EventArgs e)
        {
            Response.Write(proovedor1.EntregarProductos());
        }

        protected void btnOfrecerProductos_Click(object sender, EventArgs e)
        {
            Response.Write(proovedor1.OfrecerProductos());
        }
    }
}