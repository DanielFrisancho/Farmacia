﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class Cliente : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Delcarar objeto instanciando clase
        private static Capa_Negocio.Cliente cliente1 = new Capa_Negocio.Cliente();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            string dni = txtDni.Text;
            string frecuencia = txtFrecuencia.Text;
            if (nombre == "")
                Response.Write("Ingrese nombre");
            else if (dni == "")
                Response.Write("Ingrese dni");
            else if (frecuencia == "")
                Response.Write("Ingrese la frecuencia");
            else
            {
                cliente1.Nombre = nombre;
                cliente1.Dni = dni;
                cliente1.Frecuencia = frecuencia;
                // enviar un mensaje de conformidad
                Response.Write("Se ha agregado los atributos al objeto");
            }
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  " Nombre:" + cliente1.Nombre + " Dni:" + cliente1.Dni + " Frecuencia:" + cliente1.Frecuencia
                );
        }

        protected void btnElegirProducto_Click(object sender, EventArgs e)
        {
            Response.Write(cliente1.ElegirProducto());
        }

        protected void btnPagar_Click(object sender, EventArgs e)
        {
            Response.Write(cliente1.Pagar());
        }

        protected void btnReclamar_Click(object sender, EventArgs e)
        {
            Response.Write(cliente1.Reclamar());
        }

        protected void btnDevolver_Click(object sender, EventArgs e)
        {
            Response.Write(cliente1.Devolver());
        }

        protected void btnCanjear_Click(object sender, EventArgs e)
        {
            Response.Write(cliente1.Canjear());
        }

        protected void btnRecepcionarProducto_Click(object sender, EventArgs e)
        {
            Response.Write(cliente1.RecepcionarProducto());
        }
    }
}