﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class Producto : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Delcarar objeto instanciando clase
        private static Capa_Negocio.Producto producto1 = new Capa_Negocio.Producto();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string nombre = txtNombre.Text;
            decimal precio = decimal.Parse(txtPrecio.Text);
            string presentacion = txtPresentacion.Text;
            DateTime fechaVencimiento = DateTime.Parse(txtFechaVencimiento.Text);
            DateTime fechaFabricacion = DateTime.Parse(txtFechaFabricacion.Text);
            int unidadesDisponibles = int.Parse(txtUnidadesDisponibles.Text);
            if (nombre == "")
                Response.Write("Ingrese nombre");
            else if (precio == 0)
                Response.Write("Ingrese precio");
            else if (presentacion == "")
                Response.Write("Ingrese la presentacion");
            else if (fechaVencimiento == null)
                Response.Write("Ingrese la fecha de vencimiento");
            else if (fechaFabricacion == null)
                Response.Write("Ingrese la fecha de fabricacion");
            else
            {
                producto1.Nombre = nombre;
                producto1.Precio = precio;
                producto1.Presentacion = presentacion;
                producto1.FechaVencimiento = fechaVencimiento;
                producto1.FechaFabricacion = fechaFabricacion;
                producto1.UnidadesDisponibles = unidadesDisponibles;
                // enviar un mensaje de conformidad
                Response.Write("Se ha agregado los atributos al objeto");
            }
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  " Nombre:" + producto1.Nombre + " Precio:" + producto1.Precio + " Presentacion:" + producto1.Presentacion + " Fecha de Vencimiento:" + producto1.FechaVencimiento + " Fecha de Dabricacion:" + producto1.FechaFabricacion + "Unidades Disponibles" + producto1.UnidadesDisponibles
                );
        }

        protected void btnCaducar_Click(object sender, EventArgs e)
        {
            Response.Write(producto1.Caducar());
        }

        protected void btnCurar_Click(object sender, EventArgs e)
        {
            Response.Write(producto1.Curar());
        }
    }
}