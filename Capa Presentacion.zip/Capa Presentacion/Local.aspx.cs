﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Capa_Presentacion
{
    public partial class Local : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
        //Delcarar objeto instanciando clase
        private static Capa_Negocio.Local local1 = new Capa_Negocio.Local();
        protected void btnLeer_Click(object sender, EventArgs e)
        {
            string ubicacion = txtUbicacion.Text;
            string espacio = txtEspacio.Text;
            string horaApertura = txtHoraApertura.Text;
            if (ubicacion == "")
                Response.Write("Ingrese ubicacion");
            else if (espacio == "")
                Response.Write("Ingrese espacio");
            else if (horaApertura == "")
                Response.Write("Ingrese hora de apertura");
            else
            {
                local1.Ubicacion = ubicacion;
                local1.Espacio = espacio;
                local1.HoraApertura = horaApertura;
                // enviar un mensaje de conformidad
                Response.Write("Se ha agregado los atributos al objeto");
            }
        }

        protected void btnEscribir_Click(object sender, EventArgs e)
        {
            // Escribir los atributos de los objetos
            Response.Write
                (
                  "Ubicaciion: " + local1.Ubicacion + " Espacio:" + local1.Espacio + " Hora de Apertura:" + local1.HoraApertura
                );
        }

        protected void btnRecepcionarProductos_Click(object sender, EventArgs e)
        {
            Response.Write(local1.RecepcionarProductos());
        }

        protected void btnRecepcionarClientes_Click(object sender, EventArgs e)
        {
            Response.Write(local1.RecepcionarClientes());
        }
    }
}